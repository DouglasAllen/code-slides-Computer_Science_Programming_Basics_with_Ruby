     class Account
     	def initialize(balance)
     		@balance = balance
     	end
     end
