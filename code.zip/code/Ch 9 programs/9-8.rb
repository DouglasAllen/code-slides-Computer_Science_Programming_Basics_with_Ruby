     def status
       return @balance
     end
