     class Classname
     	def initialize(var1, var2, ..., varn)
     		@variable_1 = var1
     		@variable_2 = var2
     		...
     		@variable_n = varn
     	end
     
     	def method_1
    		# code
    	end
    
    	def method_2
    		# code
    	end
     end
