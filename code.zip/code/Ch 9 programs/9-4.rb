     class Account
     	def initialize(balance, name, phone_number)
     		@balance = balance
     		@name = name
     		@phone_number = phone_number
     	end
     
     	def deposit(amount)
     		# code
    	end
    
    	def withdraw(amount)
    		# code
    	end
     end
