     def display()
       puts "Name: " + @name
       puts "Phone Number: " + @phone_number.to_s
       puts "Balance: " + @balance.to_s
     end
