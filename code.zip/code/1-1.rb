     puts "Enter first name: "	# Ask for the first name
     first_name = gets		# Store the first name
     puts "Enter last name: "	# Ask for the last name
     last_name = gets		# Store the last name
     puts "Enter middle initial: "	# Ask for the middle initial
     middle_initial = gets		# Store the middle initial

 