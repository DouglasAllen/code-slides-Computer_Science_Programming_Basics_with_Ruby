     my_string = "Good;day;sir!"
     arr = my_string.split("a")
     puts arr
     
     # The following array is created:
     # arr[0]: "Good;d"
     # arr[1]: "y;sir!"
