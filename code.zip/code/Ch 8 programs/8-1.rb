     x = 3
     y = x.multiplier(4)
     puts "The number is: " + y.to_s
