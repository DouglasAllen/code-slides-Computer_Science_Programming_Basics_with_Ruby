     my_string = "Good;day;sir!"
     arr = my_string.split(";")
     puts arr
     
     # The following array is created:
     # arr[0]: "Good"
     # arr[1]: "day"
     # arr[2]: "sir!"
