     my_string = "Good;day;sir!"
     arr = my_string.split("z")
     puts arr
     
     # The following array is created:
     # arr[0]: "Good;day;sir!"
