     case
     when (expression1)
     	# section 1
     when (expression2)
     	# section 2
     else
     	# section 3
     end
