     if (condition1)
     	# section 1
     elsif (condition2)
     	# section 2
     elsif (condition3)
     	# section 3
     else
    	# section 4
     end
