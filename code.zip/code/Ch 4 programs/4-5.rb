     if (condition)
     	# section 1
     else
     	# section 2
     end
