     # if a number is even, print out "Even"
     puts "Enter a number"	# print message
     number = gets.to_i	# get number as an integer
     if (number % 2 == 0)	# check if even
     	puts "Even"
     end
