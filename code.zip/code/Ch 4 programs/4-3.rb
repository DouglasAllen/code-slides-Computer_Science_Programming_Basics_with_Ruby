     if (condition)
     	# section 1
     end
