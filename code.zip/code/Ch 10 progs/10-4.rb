     class Item
     	def initialize(item, maker)
     		@item = item
     		@maker = maker
     	end
     
     	def display
     		puts "Item ==> " + @item
     		puts "Maker ==> " + @maker
    	end
      end
