     until (condition)
     	# statement 1
     	# statement 2
     	# ...
     	# statement n
     end
