     n = 5
     i = 0
     while (i <= n)
     	puts i
     	i = i + 1
     end
