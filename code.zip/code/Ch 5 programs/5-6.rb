     puts "Count from 0 to ? "
     n = gets.to_i
     i = 5
     while (i > 0)
     	i = i + 2
     end
