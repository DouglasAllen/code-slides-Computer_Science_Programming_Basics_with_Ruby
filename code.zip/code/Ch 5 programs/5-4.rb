     for num in 0..5
     	puts num
     end
