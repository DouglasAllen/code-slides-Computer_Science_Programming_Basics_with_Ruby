     i = 0
     
     while (i < a.size)
     	puts a[i]
     	i = i + 1
     end
