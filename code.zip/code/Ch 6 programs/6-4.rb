     arr = [73, 98, 86, 61]
     index = 0
     while (index < arr.size)
     	puts arr[index]
     	index = index + 1
     end
