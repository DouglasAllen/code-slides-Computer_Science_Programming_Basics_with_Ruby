     arr = Array.new
     arr[0] = 73 
     arr[1] = 98 
     arr[2] = 86 
     arr[3] = 61 
     arr[4] = 96
