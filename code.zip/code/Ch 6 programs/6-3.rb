     arr[0] = arr[0] + 10
     puts arr[0]
